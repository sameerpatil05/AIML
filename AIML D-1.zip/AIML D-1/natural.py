n  =int(input("Enter the no: "))
sum  = 0

for i in range(0,n):
    sum += i+1

print(sum)