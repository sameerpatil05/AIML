a = int(input("Enter the 1st no: "))
b = int(input("Enter the 2nd no: "))
c = int(input("Enter the 3rd no: "))

def average(a,b,c):
    average = (a+b+c)/3

    print("Average of 3 ns is:", average)

average(a,b,c)