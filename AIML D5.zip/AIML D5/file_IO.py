f= open("sample.txt", "w")

#data = f.read()
#data = f.readline()

data = f.write("Thenew space is ok")
print(data)

f.close()