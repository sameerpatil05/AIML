#f = open("sample2.txt", "x")

#data = f.write("something new is cooking")

f = open("sample.txt", "a")

data = f.write("\n something new is cooking")

print(data)

f.close()