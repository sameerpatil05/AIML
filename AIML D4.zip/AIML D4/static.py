class laptop:
    storage_type = "SSD"
    
    def __init__(self,RAM,Storage):
        self.RAM = RAM
        self.Storage = Storage
        
    @staticmethod
    def discounted_price(price,discount):
        final_price = price - (discount * price /100)
        print(f"the discounted price of laptop is {final_price}")
LP1 = laptop("6 GB","64 GB")
LP1 = laptop("8 GB","128 GB")    

LP1.discounted_price(40_000,10)