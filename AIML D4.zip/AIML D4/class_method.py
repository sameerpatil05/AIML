class laptop:
    storage_type = "SSD"

    def __init__(self,RAM,Storage):
        self.RAM = RAM
        self.Storage = Storage

    def get_storage_type(cls):
        print(f"The Laptop type is = {cls.storage_type}")  
    @classmethod
    def get_info(self):
        print(f"Laptop has {self.RAM} & {self.Storage} of {self.storage_type} ")

LP1 = laptop("6 GB","64 GB")
LP1 = laptop("8 GB","128 GB")    

LP1.get_storage_type()