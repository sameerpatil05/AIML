class student:
    def __init__(self,name,constituency):
        self.name = name
        self.constituency = constituency

    def get_cgpa(self):
        return self.constituency

stu1 = student("Nagesh","Hinholi Deccan")
stu2 = student("Omraje" , "Dharashiv Dist")
stu3 = student("Sanjay", "Parbhani")

print(stu1.name)
print(f"{stu1.name} belongs to the {stu1.get_cgpa} Loksabha Constituency")