class student:
    college_name = "PVG college"
    pi = 3.1
    def __init__(self,name,cgpa,pi):
        self.name = name
        self.cgpa = cgpa
        self.pi = 3.14

st1 = student("Samir", 9.14,0)

print(student.pi)
print(st1.pi)