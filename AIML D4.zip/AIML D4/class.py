class student:

    subject = "Python"
    standard = "BE"
    city = "Nashik"

stu1 = student()
stu2 = student()

print(stu1.subject, stu2.standard, stu1.city, stu2.city)

