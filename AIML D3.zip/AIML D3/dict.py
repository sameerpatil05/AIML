info = {
    "Name" : "Samir Patil",
    "CGPA" : 9.2,
    "Specs" : ["Comp","AI"]

}
print(info.keys())

print(info.values())

print(info.items())

print(info.get("CGPA2"))

info.update({
    3.14: "pi"
})