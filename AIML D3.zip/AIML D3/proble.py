info = [
("Alice", "Math"),
("Bob", "Science"),
("Alice", "Science"),
("Charlie", "Math"),
("Bob", "Math"),
("Alice", "English"),
("Charlie", "English"),
]
# unique_set = set()
# for name,course in info:
#     unique_set.add(course)

# print(unique_set)

# if(course == "English"):
#     print(name)


dict = ()

for name,course in info:
    if(info.get(name) == None):
        dict.update(name:set())
        dict[name].add(course)

    else:
        dict[name].add(course)