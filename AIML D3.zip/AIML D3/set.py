S = {6,8,3,9,0,3,2,1}

S.add(5)
S.remove(8)
#S.clear()
S.pop()

#print(S)

S1 = {8,3,9,0,3,2,1}
S2 = {1,6,4,8,9,15}

print(S1.union(S2))

print(S1.intersection(S2))