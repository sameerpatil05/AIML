tup = (7,4,8,8,1,8)
sum=0

for val in tup:
    sum+=val

print("the sum of Tup is ",sum)    

tup = (7,4,8,8,1,8)

print(tup.index(8))

print(tup.count(8))